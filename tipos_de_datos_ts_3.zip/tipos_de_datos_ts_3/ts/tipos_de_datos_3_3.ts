/* Declaramos un tipo específico de datos con una serie de opciones establecidas */
type Colores = "Verde" | "Negro" | "Rojo" | "Azul";

function mostrarColor(color:Colores){
    let colorElegido: string = `<div>El color es ${color}.</div>`;
    document.write(colorElegido);
}

mostrarColor("Rojo");
mostrarColor("Verde");
