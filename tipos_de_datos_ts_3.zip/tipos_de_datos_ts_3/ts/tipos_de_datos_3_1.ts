/* Declaramos las variables */
let nombre: string = "Antonio"; // Una cadena se declara con la palabra reservada string
let salario: number = 1218.12; // Las variables number pueden ser, indiferentemente, enteros o flotantes.
let frase: string = `Me llamo ${nombre} y gano ${salario} € al mes.`; // Atento a la sintaxis

/* Las mostramos en consola */
console.log("La variable 'nombre' contiene: ", nombre);
console.log("La variable 'salario' contiene: ", salario);
console.log("La variable 'frase' contiene: ", frase);


