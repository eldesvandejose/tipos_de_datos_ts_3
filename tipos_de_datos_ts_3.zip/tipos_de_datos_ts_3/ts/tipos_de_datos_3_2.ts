/* Declaramos unas variables convencionales */
let otro_nombre: string = "Laura";
let otro_salario: number = 1342.69;

// Declaramos una plantilla multilinea
let plantillaML: string = `<div> El nombre de esta persona es ${otro_nombre}</div>
<div>Su salario es de ${otro_salario} euros/mes.</div>`;

// Mostramos la plantilla en el documento.
document.write(plantillaML);

