"use strict";
/* Declaramos unas variables convencionales */
let otro_nombre = "Laura";
let otro_salario = 1342.69;
// Declaramos una plantilla multilinea
let plantillaML = `<div> El nombre de esta persona es ${otro_nombre}</div>
<div>Su salario es de ${otro_salario} euros/mes.</div>`;
// Mostramos la plantilla en el documento.
document.write(plantillaML);
