"use strict";
function mostrarColor(color) {
    let colorElegido = `<div>El color es ${color}.</div>`;
    document.write(colorElegido);
}
mostrarColor("Rojo");
mostrarColor("Verde");

